import random
import json
import os

from pico2d import *

import game_framework
import characterselect_state



name = "MainState"

global state  # 0일 때 등장애니메이션 1일 때 이동애니
global startspeed
global selectcharacter
global Player_missile
global timer
state = 0
boy = None
map = None
font = None
startspeed = 50

class Timer:
    def __init__(self):
        self.FirstEnemy_timer = 3
        self.SecondEnemy_timer = 49

    def update(self):
        self.FirstEnemy_timer = self.FirstEnemy_timer + 1
        if self.FirstEnemy_timer % 15 == 0:
            enemy = FirstEnemy()
            FirstEnemys.append(enemy)
        if self.FirstEnemy_timer % 30 == 0:
            enemy = FirstEnemy()
            FirstEnemys.append(enemy)

        if self.FirstEnemy_timer >100:
            self.SecondEnemy_timer = self.SecondEnemy_timer + 1

            if self.SecondEnemy_timer % 50== 0:
                enemy = SecondEnemy()
                SecondEnemys.append(enemy)

            for enemy in SecondEnemys:
                if enemy.attacked == 1:
                    if self.SecondEnemy_timer % 2 == 0:
                            enemy.frame = 1
                    else:
                        enemy.frame =0
                        enemy.attacked = 0


class Map:
    def __init__(self):
        self.image = load_image('resource\\background\\map1.png')
        self.x, self.y = 0,0
    def update(self):
        global startspeed
        if state == 0 :
            if self.y < 400:
                self.y += startspeed
                startspeed = startspeed - 3
            else:
                self.y = 0
        else :
            if self.y < 400:
                self.y += 20
            else:
                self.y = 20

    def draw(self):
        self.image.clip_draw(0, 0, 500, 750 + self.y, 250, 375)

class Player:
    def __init__(self):
        if state == 0:
            self.x, self.y = 250, 0
            self.frame = 0
            self.image = load_image('resource\\player\\player1_appear_animation.png')
            self.dir = 1
    def update(self):
        global state
        if state == 0:
            if self.frame < 10:
                self.frame = self.frame + 1
                self.y += 10
            else:
                state = 1
                self.x, self.y = 250, 200
                self.move = 0   # 0이면 정지 1이면 오른쪽 2면 왼쪽
                self.frame = 6
                self.image = load_image('resource\\player\\player1_animation.png')
                self.dir = 1
        if state == 1:
            if self.move == 0 :
                if self.frame % 2 == 0:
                    self.frame = self.frame + 1
                elif self.frame % 2 == 1:
                    self.frame = self.frame - 1
            if self.move == 1 :
                if self.x < 470:
                    self.x += 15
                if self.frame < 13:
                    self.frame = self.frame + 1
            if self.move == 2:
                if self.x > 30:
                   self.x -= 15
                if self.frame > 0:
                    self.frame = self.frame - 1
            if self.move == 3 :
                if self.y < 650:
                    self.y += 10
            if self.move == 4:
                if self.y > 50:
                    self.y -= 10
        delay(0.07)

    def draw(self):
        if state == 0:
            self.image.clip_draw(self.frame * 50, 0, 50, 250, self.x, self.y)
        elif state == 1:
            self.image.clip_draw(self.frame * 50, 0, 50, 70, self.x, self.y)

class Missile:
    def __init__(self, x, y):
            self.x, self.y = x, y
            self.level = 0
            self.frame = 0
            self.image = load_image('resource\\player\\player_missile.png')

    def update(self):
        self.y += 20
        self.frame = self.frame + 1
        if self.frame > 3:
            self.frame = 0

    def draw(self):
        if self.level == 0:
            self.image.clip_draw(self.frame * 40, 50, 40, 50, self.x, self.y+20)
        if self.level == 1:
            self.image.clip_draw(self.frame * 40, 0, 40, 50, self.x, self.y+20)

class FirstEnemy:
    image = None
    def __init__(self):
        self.x, self.y = random.randint(30, 470), 800
        self.frame = 3
        self.missile = 0
        if FirstEnemy.image == None:
            self.image = load_image('resource\\Enemy\\Enemy_1.png')

    def update(self):
        if state == 1:
            for FirstEnemy in FirstEnemys:
                if FirstEnemy.y < -50:
                    FirstEnemys.remove(FirstEnemy)
            self.y -= 10
        self.missile = self.missile + 1
        if self.missile % 25 == 0:
            missile = Enemy_missile(self.x, self.y-70)
            enemy_missile.append(missile)



    def draw(self):
        self.image.clip_draw(self.frame * 55, 0, 55, 95, self.x, self.y)

class SecondEnemy:
    image = None
    def __init__(self):
        self.x, self.y = random.randint(30, 470), 800
        self.frame = 0
        self.count = 0
        self.missile = 0
        self.attacked = 0
        if SecondEnemy.image == None:
            self.image = load_image('resource\\Enemy\\Enemy_2.png')

    def update(self):
        if state == 1:
            for SecondEnemy in SecondEnemys:
                if SecondEnemy.y < -50:
                    SecondEnemys.remove(SecondEnemy)
            self.y -= 10
            self.missile = self.missile + 1
        if self.missile % 25 == 0:
            missile = Enemy_missile(self.x-15, self.y-70)
            enemy_missile.append(missile)
            missile = Enemy_missile(self.x, self.y-70)
            enemy_missile.append(missile)
            missile = Enemy_missile(self.x+15, self.y-70)
            enemy_missile.append(missile)



    def draw(self):
        self.image.clip_draw(0+(self.frame*117), 0, 117, 100, self.x, self.y)

class Enemy_missile:
    image = None
    def __init__(self, x, y):
        self.x, self.y = x, y
        if Enemy_missile.image == None:
            self.image = load_image('resource\\Enemy\\Enemy_missile.png')

    def update(self):
        self.y -= 20

    def draw(self):
        self.image.clip_draw(0, 0, 31, 31, self.x, self.y + 40 )

class Firstenemy_Explosion:
    image = None
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.frame = 0
        if Enemy_missile.image == None:
            self.image = load_image('resource\\Enemy\\Enemy1_explosion.png')

    def update(self):
        self.frame = self.frame + 1
    def draw(self):
        self.image.clip_draw( self.frame * 80, 0, 80, 80, self.x, self.y )


class Secondenemy_Explosion:
    image = None
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.frame = 0
        if Enemy_missile.image == None:
            self.image = load_image('resource\\Enemy\\Enemy2_explosion.png')

    def update(self):
        self.frame = self.frame + 1
    def draw(self):
        self.image.clip_draw( self.frame * 100, 0, 100, 100, self.x, self.y )



def enter():
    global timer, player, map, Player_missile, FirstEnemys, SecondEnemys, enemy_missile, firstenemy_explosion, secondenemy_explosion
    timer = Timer()
    player = Player()
    map = Map()

    FirstEnemys = []
    SecondEnemys = []
    Player_missile = []
    enemy_missile = []
    firstenemy_explosion = []
    secondenemy_explosion = []
def exit():
    global timer, player, map, Player_missile, FirstEnemys, SecondEnemys, enemy_missile, firstenemy_explosion, secondenemy_explosion
    del(timer)
    del(player)
    del(map)

    del(FirstEnemys)
    del(SecondEnemys)
    del(Player_missile)
    del(enemy_missile)
    del(firstenemy_explosion)
    del(secondenemy_explosion)


def pause():
    pass


def resume():
    pass


def handle_events():
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            game_framework.quit()
        if event.type == SDL_KEYDOWN and event.key == SDLK_RIGHT:
            player.move = 1
        elif event.type == SDL_KEYDOWN and event.key == SDLK_LEFT:
            player.move = 2
        elif event.type == SDL_KEYDOWN and event.key == SDLK_UP:
            player.move = 3
        elif event.type == SDL_KEYDOWN and event.key == SDLK_DOWN:
            player.move = 4
        if event.type == SDL_KEYUP and event.key == SDLK_RIGHT:
            if player.move == 1:
                player.move = 0
            player.frame = 6
        if event.type == SDL_KEYUP and event.key == SDLK_LEFT:
            if player.move == 2:
                player.move = 0
            player.frame = 6
        if event.type == SDL_KEYUP and event.key == SDLK_UP:
            if player.move == 3:
                player.move = 0
            player.frame = 6
        if event.type == SDL_KEYUP and event.key == SDLK_DOWN:
            if player.move == 4:
                player.move = 0
            player.frame = 6
            #여기까지 캐릭터 이동
        if event.type == SDL_KEYDOWN and event.key == SDLK_SPACE and state == 1:
            newmissile = Missile(player.x, player.y)
            Player_missile.append(newmissile)


def update():
    timer.update()
    player.update()
    map.update()
    for enemy in FirstEnemys :
        enemy.update()
    for SecondEnemy in SecondEnemys :
        SecondEnemy.update()
    for member in Player_missile :
        member.update()
    for member in enemy_missile :
        member.update()
    for member in firstenemy_explosion :
        member.update()
        if member.frame == 10:
            firstenemy_explosion.remove(member)

    for member in secondenemy_explosion :
        member.update()
        if member.frame == 10:
            secondenemy_explosion.remove(member)
    for missile in Player_missile:
        for enemy in FirstEnemys:
            if missile.y > enemy.y - 30 and missile.y < enemy.y + 30 and missile.x > enemy.x-20 and missile.x < enemy.x + 20 :
                newexplosion = Firstenemy_Explosion(enemy.x, enemy.y)
                firstenemy_explosion.append(newexplosion);
                FirstEnemys.remove(enemy)
                Player_missile.remove(missile)

    for missile in Player_missile:
        for enemy in SecondEnemys:
            if missile.y > enemy.y - 50 and missile.y < enemy.y + 50 and missile.x > enemy.x - 55 and missile.x < enemy.x + 55 :
                enemy.count += 1
                enemy.attacked = 1
                Player_missile.remove(missile)
                if enemy.count == 3:
                    SecondEnemys.remove(enemy)
                    newexplosion = Secondenemy_Explosion(enemy.x, enemy.y)
                    secondenemy_explosion.append(newexplosion);



def draw():
    clear_canvas()
    map.draw()
    player.draw()
    for member in FirstEnemys :
        member.draw()
    for member in SecondEnemys :
        member.draw()
    for member in Player_missile :
        member.draw()
    for member in enemy_missile :
        member.draw()
    for member in firstenemy_explosion :
        member.draw()
    for member in secondenemy_explosion :
        member.draw()
    update_canvas()