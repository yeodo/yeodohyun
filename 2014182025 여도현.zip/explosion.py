from pico2d import *

class Enemy_explosion:
    image = None
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.frame = 0
        if Enemy_explosion.image == None:
            self.image = load_image('resource\\Enemy\\Enemy1_explosion.png')

    def update(self):
        self.frame = self.frame + 1
    def draw(self):
        self.image.clip_draw( self.frame * 80, 0, 80, 80, self.x, self.y )


class Bomb_explosion:
    image = None
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.frame = 0
        if Bomb_explosion.image == None:
            self.image = load_image('resource\\player\\bomb_explosion.png')
    def update(self):
        self.frame = self.frame + 1


    def draw_bb(self):
        draw_rectangle(*self.get_bb())
    def get_bb(self):
        return self.x - 160, self.y - 160 , self.x + 160, self.y + 160
    def draw(self):
        self.image.clip_draw( self.frame * 320, 0, 320, 320, self.x, self.y )
