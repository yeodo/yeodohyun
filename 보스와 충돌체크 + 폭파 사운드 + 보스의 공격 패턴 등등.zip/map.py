from pico2d import *

class Map:
    def __init__(self):
        self.image = load_image('resource\\background\\map1.png')
        self.x, self.y = 0,0
    def update(self):
        if self.y < 400:
            self.y += 10
        else:
            self.y = 20

    def draw(self):
        self.image.clip_draw(0, 0, 500, 750 + self.y, 250, 375)

    def __del__(self):
        del self.image
